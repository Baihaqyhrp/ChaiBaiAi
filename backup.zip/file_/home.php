<?php include '_parcials/header.php';?>
  <body>
    

    <div class="container mt-4">
      <div
        class="p-5 text-dark d-flex align-items-center position-relative"
        style="
          border-top: 4px solid rgb(90, 91, 91);
          border-right: 20px solid rgb(90, 91, 91);
          border-top-right-radius: 40px;
          border-radius: 0 0 50px 10px;
          border-top-left-radius: 40px;"
      >
        <!-- Konten Teks -->
        <div>
          <h1 style="font-size: 60px">
            <b>ChatBaiAi Engine Update v.3 (vee-3)</b>
          </h1>
          <p class="text-muted">
            Gunakan chatbot AI futuristik di server lokal Anda. Layanan chatbot
            virtual ini dapat Anda gunakan untuk bisnis sehari-hari dan dapat
            diintegrasikan langsung ke aplikasi Anda.
          </p>
        </div>
      </div>
    </div>

    <!-- Bagian Fitur -->
    <div class="container mt-5">
      <h2 class="mb-3 fw-bolder">ChatBaiAi dengan Kemampuan Unggul</h2>
      <p>
        Dengan tingginya permintaan akan teknologi AI, chatbot generasi
        berikutnya telah dikembangkan untuk dapat digunakan kembali dalam
        pengoptimalan kode di Server Aurora.
      </p>
      <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        <!-- Fitur 1 -->
        <div class="col">
          <div
            class="card p-3 bg-light"
            style="
              border-top: 4px solid rgb(24, 22, 26);
              border-right: 4px solid rgb(24, 22, 26);
              border-radius: 0 0 50px 10px;
            "
          >
            <i class="bi bi-robot text-primary fs-1"></i>
            <h5 class="mt-3"><b>AI Chatbot</b></h5>
            <p>
              Chatbot AI yang sangat canggih untuk pengembang, siap membantu
              Anda kapan saja saat Anda mengalami kebuntuan dalam pengembangan.
            </p>
          </div>
        </div>

        <!-- Fitur 2 -->
        <div class="col">
          <div
            class="card p-3 bg-light"
            style="
              border-top: 4px solid rgb(24, 22, 26);
              border-right: 4px solid rgb(24, 22, 26);
              border-radius: 0 0 50px 10px;
            "
          >
            <i class="bi bi-shield-lock text-danger fs-1"></i>
            <h5 class="mt-3"><b>Keamanan</b></h5>
            <p>
              Fitur keamanan ChatBaiAi dan sistem anti-fraud akan mendeteksi
              akses mencurigakan, di mana pun Anda berada.
            </p>
          </div>
        </div>

        <!-- Fitur 3 -->
        <div class="col">
          <div
            class="card p-3 bg-light"
            style="
              border-top: 4px solid rgb(24, 22, 26);
              border-right: 4px solid rgb(24, 22, 26);
              border-radius: 0 0 50px 10px;
            "
          >
            <i class="bi bi-speedometer2 text-success fs-1"></i>
            <h5 class="mt-3"><b>Respon Cepat</b></h5>
            <p>
              Anda tidak akan terjebak dalam proses pengembangan kode AI. Hanya
              dalam 0,2 detik, solusi akan diberikan dengan cepat.
            </p>
          </div>
        </div>

        <!-- Fitur 4 -->
        <div class="col">
          <div
            class="card p-3 bg-light"
            style="
              border-top: 4px solid rgb(24, 22, 26);
              border-right: 4px solid rgb(24, 22, 26);
              border-radius: 0 0 50px 10px;
            "
          >
            <i class="bi bi-cloud-arrow-down text-warning fs-1"></i>
            <h5 class="mt-3"><b>Opsi Cloud</b></h5>
            <p>
              ChatBaiAi menawarkan opsi cloud untuk mengumpulkan dataset yang
              Anda kirimkan, dan dataset ini dapat digunakan kembali di setiap
              proyek Anda.
            </p>
          </div>
        </div>
      </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
