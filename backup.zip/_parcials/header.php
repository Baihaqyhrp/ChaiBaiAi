<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css">
    
</head>
<body>
<nav class="navbar navbar-expand-lg bg-secondary border-bottom border-5 border-warning">
      <div class="container-fluid">
        <a class="navbar-brand text-white fw-bold" href="#">
          <h1 class="mb-0">
            <i class="bi bi-fingerprint text-warning"></i
            ><b>&nbsp; ChatBaiAi</b>
          </h1>
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarScroll"
          aria-controls="navbarScroll"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarScroll"
        >
          <ul class="navbar-nav me-3 my-2 my-lg-0 navbar-nav-scroll">
            <li class="nav-item">
              <a class="nav-link text-white" href="#" style="font-size: 20px"
                >Beranda</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" style="font-size: 20px">Harga</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" style="font-size: 20px"
                >Produk AI</a
              >
            </li>
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle text-white"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
                style="font-size: 20px"
              >
                Dokumentasi
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Integrasi API</a></li>
                <li>
                  <a class="dropdown-item" href="#">Chatbot AI Tertanam</a>
                </li>
                <li>
                  <hr class="dropdown-divider" />
                </li>
                <li><a class="dropdown-item" href="#">Dataset Cloud</a></li>
              </ul>
            </li>
          </ul>

          <!-- Tombol Login -->
          <a
            href="#"
            class="btn btn-warning fw-bolder"
            style="border-radius: 20px"
            >Login Sekarang <i class="bi bi-arrow-right"></i
          ></a>
        </div>
      </div>
    </nav>

    
</body>
</html>